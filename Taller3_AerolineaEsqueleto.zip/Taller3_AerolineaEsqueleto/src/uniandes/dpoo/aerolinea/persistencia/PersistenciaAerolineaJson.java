package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {

    @Override
    public void cargarAerolinea(String archivo, Aerolinea aerolinea)
            throws IOException, InformacionInconsistenteException {
        String jsonCompleto = new String(Files.readAllBytes(new File(archivo).toPath()));
        JSONObject raiz = new JSONObject(jsonCompleto);
        
        Map<String, Aeropuerto> aeropByCode = new HashMap<>();
        Map<String, Avion>      avionByName = new HashMap<>();
        Map<String, Ruta>       rutaByCode  = new HashMap<>();


       
        JSONArray jAeropuertos = raiz.optJSONArray("aeropuertos");
        if (jAeropuertos != null) {
            for (int i = 0; i < jAeropuertos.length(); i++) {
                JSONObject o = jAeropuertos.getJSONObject(i);
               
            
                Aeropuerto a = new Aeropuerto(
				    o.getString("nombre"),
				    o.getString("codigo"),
				    o.getString("nombreCiudad"),
				    o.getDouble("latitud"),
				    o.getDouble("longitud")
				                        
				);
				aeropByCode.put(a.getCodigo(), a);
            }
        }

        // Aviones 
        JSONArray jAviones = raiz.optJSONArray("aviones");
        if (jAviones != null) {
            for (int i = 0; i < jAviones.length(); i++) {
                JSONObject o = jAviones.getJSONObject(i);
                Avion av = new Avion(o.getString("nombre"), o.getInt("capacidad"));
                aerolinea.agregarAvion(av);
                avionByName.put(av.getNombre(), av);
            }
        }

        // Rutas
        JSONArray jRutas = raiz.optJSONArray("rutas");
        if (jRutas != null) {
            for (int i = 0; i < jRutas.length(); i++) {
                JSONObject o = jRutas.getJSONObject(i);
                Aeropuerto org = aeropByCode.get(o.getString("origen"));
                Aeropuerto dst = aeropByCode.get(o.getString("destino"));
                if (org == null || dst == null) {
                    throw new InformacionInconsistenteException("Ruta con aeropuerto inexistente: " + o);
                }
                Ruta r = new Ruta(
                    o.getString("horaSalida"),
                    o.getString("horaLlegada"),
                    o.getString("codigoRuta"),
                    org, dst
                );
                aerolinea.agregarRuta(r);
                rutaByCode.put(r.getCodigoRuta(), r);
            }
        }

        // Vuelos 
        JSONArray jVuelos = raiz.optJSONArray("vuelos");
        if (jVuelos != null) {
            for (int i = 0; i < jVuelos.length(); i++) {
                JSONObject o = jVuelos.getJSONObject(i);
                String codRuta = o.getString("codigoRuta");
                String nombreAvion = o.getString("avion");
                String fecha = o.getString("fecha");

                
                if (!rutaByCode.containsKey(codRuta) || !avionByName.containsKey(nombreAvion)) {
                    throw new InformacionInconsistenteException("Vuelo inconsistente (ruta/avión no encontrado): " + o);
                }
                try {
                    aerolinea.programarVuelo(fecha, codRuta, nombreAvion);
                } catch (Exception e) {

                    throw new InformacionInconsistenteException("No se pudo programar el vuelo");
                }
            }
        }
    }

    @Override
    public void salvarAerolinea(String archivo, Aerolinea aerolinea) throws IOException {
        JSONObject jobject = new JSONObject();

        // Aeropuertos

        Map<String, Aeropuerto> aeropUnicos = new LinkedHashMap<>();
        for (Ruta r : aerolinea.getRutas()) {
            Aeropuerto o = r.getOrigen();
            Aeropuerto d = r.getDestino();
            if (o != null) aeropUnicos.putIfAbsent(o.getCodigo(), o);
            if (d != null) aeropUnicos.putIfAbsent(d.getCodigo(), d);
        }
        JSONArray jAeropuertos = new JSONArray();
        for (Aeropuerto a : aeropUnicos.values()) {
            JSONObject o = new JSONObject();
            o.put("nombre", a.getNombre());
            o.put("codigo", a.getCodigo());
            o.put("nombreCiudad", a.getNombreCiudad());
            o.put("latitud", a.getLatitud());
            o.put("longitud", a.getLongitud());
            jAeropuertos.put(o);
        }
        jobject.put("aeropuertos", jAeropuertos);

        //Aviones
        JSONArray jAviones = new JSONArray();
        for (Avion av : aerolinea.getAviones()) {
            JSONObject o = new JSONObject();
            o.put("nombre", av.getNombre());
            o.put("capacidad", av.getCapacidad());
            jAviones.put(o);
        }
        jobject.put("aviones", jAviones);

        // Rutas
        JSONArray jRutas = new JSONArray();
        for (Ruta r : aerolinea.getRutas()) {
            JSONObject o = new JSONObject();
            o.put("codigoRuta", r.getCodigoRuta());
            o.put("horaSalida", r.getHoraSalida());
            o.put("horaLlegada", r.getHoraLlegada());
            o.put("origen", r.getOrigen().getCodigo());
            o.put("destino", r.getDestino().getCodigo());
            jRutas.put(o);
        }
        jobject.put("rutas", jRutas);

        // Vuelos
        JSONArray jVuelos = new JSONArray();
        for (Vuelo v : aerolinea.getVuelos()) {
            JSONObject o = new JSONObject();
            o.put("fecha", v.getFecha());
            o.put("codigoRuta", v.getRuta().getCodigoRuta());
            o.put("avion", v.getAvion().getNombre());
            jVuelos.put(o);
        }
        jobject.put("vuelos", jVuelos);


        PrintWriter pw = new PrintWriter(archivo);
        jobject.write(pw, 2, 0);
        pw.close();
    }
}



