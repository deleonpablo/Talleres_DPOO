package uniandes.dpoo.aerolinea.modelo.cliente;


import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.*;
import java.util.*;

public abstract class Cliente {
	
	
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	public Cliente() {
		this.tiquetesSinUsar = new ArrayList<>();
		this.tiquetesUsados = new ArrayList<>();
		
	}
	
	public abstract String getTipoCliente();
	public abstract String getIdentificador();
	
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	
	
	public int calcularValorTotalTiquetes() {
		int valor = 0;
		
		for(Tiquete tiquete : tiquetesSinUsar) {
			valor += tiquete.getTarifa();
			
		}
		
		for(Tiquete tiquete: tiquetesUsados) {
			valor += tiquete.getTarifa();
		}
		
		return valor;
		
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		for (Tiquete tiquete: tiquetesSinUsar) {
			if (tiquete.getVuelo().equals(vuelo) ) {
				tiquete.marcarComoUsado();
				tiquetesSinUsar.remove(tiquete);
				tiquetesUsados.add(tiquete);
			}
		
		}
		
	}
	
	
	
	
	
	
	
	

}
