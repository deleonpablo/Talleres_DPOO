package uniandes.dpoo.aerolinea.modelo;
import java.util.Collection;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	private String fecha;
	
	private Ruta ruta;
	private Avion avion;
	
	private Map<String,Tiquete> tiquetes;
	
	public Vuelo(Ruta ruta, Avion avion, String fecha) {
		this.ruta = ruta;
		this.avion = avion;
		this.fecha = fecha;
	}
	
	public String getFecha() {
		return fecha;
	}

	public Ruta getRuta() {
		return ruta;
	}

	public Avion getAvion() {
		return avion;
	}

	public Collection<Tiquete> getTiquetes() {
		return tiquetes.values();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		int precio = calculadora.calcularTarifa(null, cliente) * cantidad;
		return precio;
		

		
	}
	
	
	



	
}
