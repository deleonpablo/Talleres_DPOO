package uniandes.dpoo.aerolinea.modelo.tarifas;
import java.util.Collection;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;


public abstract class CalculadoraTarifas {
	
	public double IMPUESTO = 0.28;
	
	private Vuelo vuelo;
	private Cliente cliente;
	
	
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		int tarifa = 0;
		Collection<Tiquete> tiquetes = vuelo.getTiquetes();
		for (Tiquete t:tiquetes) {
			if(t.getCliente().equals(cliente)) {
				tarifa = t.getTarifa();		
			}
		}
		return tarifa;
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	protected abstract double CalcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		Aeropuerto destino = ruta.getDestino();
		Aeropuerto origen = ruta.getOrigen();
		
		int distancia = Aeropuerto.calcularDistancia(destino, origen);
		return distancia;
			
	}
	protected int calcularValorImpuestos(int costoBase) {
		return (int) ((int)costoBase + costoBase*IMPUESTO);
	}
	
	
		
		
	}
	


