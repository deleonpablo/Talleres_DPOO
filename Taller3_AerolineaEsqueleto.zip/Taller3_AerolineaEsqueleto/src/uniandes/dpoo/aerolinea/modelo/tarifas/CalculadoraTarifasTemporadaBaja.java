package uniandes.dpoo.aerolinea.modelo.tarifas;

import java.util.*;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;



public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
	
	
	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_GRANDES = 0.2;
	

	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		Ruta ruta = vuelo.getRuta();
		Aeropuerto destino = ruta.getDestino();
		Aeropuerto origen = ruta.getOrigen();
		int distancia = Aeropuerto.calcularDistancia(destino, origen);
		int tarifa = 0;
		if (cliente.getTipoCliente().equals("CORPORATIVO")){
			tarifa = distancia * COSTO_POR_KM_CORPORATIVO;
		}
		else {
			tarifa = distancia * COSTO_POR_KM_NATURAL;
		}
	
		return tarifa;
	}
	@Override
	protected double CalcularPorcentajeDescuento(Cliente cliente) {
		double descuento = 0;
		if (cliente.getTipoCliente().equals("CORPORATIVO")) {
			ClienteCorporativo corp = (ClienteCorporativo) cliente;
			int tamanioEmpresa = corp.getTamanoEmpresa();
			if (tamanioEmpresa == 1) {
				descuento = DESCUENTO_GRANDES;
			}
			else if (tamanioEmpresa == 2) {
				descuento = DESCUENTO_MEDIANAS;
			}
			else {
				descuento = DESCUENTO_PEQ;
			}
		}

		return descuento;
	}

	
}
